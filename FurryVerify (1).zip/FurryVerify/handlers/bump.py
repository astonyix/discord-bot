import discord
from discord.ext import commands, tasks
import asyncio
from datetime import datetime, timedelta
import pytz
import json
import os

BUMP_REMINDER_CHANNEL_ID = 994238679910449266  # Bumping channel

class BumpSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bump_check.start()

    def get_next_slot_start(self, current_time):
        """Get the start time of the next bump slot"""
        # Define slot start hours
        slot_starts = [0, 6, 12, 18]

        # Convert current time to UTC
        utc_time = current_time.astimezone(pytz.UTC)
        current_hour = utc_time.hour

        # Find the next slot
        for hour in slot_starts:
            if current_hour < hour:
                next_slot = utc_time.replace(hour=hour, minute=0, second=0, microsecond=0)
                return next_slot

        # If we're past the last slot, get the first slot of next day
        next_slot = utc_time.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
        return next_slot

    @tasks.loop(minutes=1)  # Check every minute to ensure we don't miss the 5-minute window
    async def bump_check(self):
        """Check if it's almost time for the next bump slot"""
        try:
            current_time = datetime.now(pytz.UTC)
            next_slot = self.get_next_slot_start(current_time)
            time_until_slot = next_slot - current_time

            # If we're 5 minutes before the next slot
            if timedelta(minutes=4, seconds=30) <= time_until_slot <= timedelta(minutes=5, seconds=30):
                channel = self.bot.get_channel(BUMP_REMINDER_CHANNEL_ID)
                if channel:
                    # Format the message with the next slot's time
                    slot_start = next_slot.strftime("%H:%M UTC")
                    slot_end = (next_slot + timedelta(hours=6)).strftime("%H:%M UTC")

                    await channel.send(
                        f"🔔 <@&994238679306477680> Bump window opens in 5 minutes!\n"
                        f"Next bump window: `{slot_start} - {slot_end}`\n"
                        f"Get ready to bump! ⏰"
                    )
                    print(f"Sent bump reminder for slot starting at {slot_start}")

        except Exception as e:
            print(f"Error in bump check: {e}")

    @bump_check.before_loop
    async def before_bump_check(self):
        """Wait until bot is ready before starting the loop"""
        await self.bot.wait_until_ready()

    def cog_unload(self):
        """Clean up when cog is unloaded"""
        self.bump_check.cancel()

async def setup(bot):
    await bot.add_cog(BumpSystem(bot))