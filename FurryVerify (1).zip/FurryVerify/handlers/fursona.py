import discord
from discord.ext import commands
import config
from utils.helpers import check_mod_permissions, create_embed
import asyncio
import json
import os

# File to store pending applications
PENDING_FURSONAS_FILE = 'pending_fursonas.json'
PENDING_IMAGES_FILE = 'pending_images.json'
USER_FURSONAS_FILE = 'user_fursonas.json'

# Load saved data
def load_saved_data():
    global pending_fursonas, pending_images, user_fursonas
    try:
        if os.path.exists(PENDING_FURSONAS_FILE):
            with open(PENDING_FURSONAS_FILE, 'r') as f:
                pending_fursonas = json.load(f)
        if os.path.exists(PENDING_IMAGES_FILE):
            with open(PENDING_IMAGES_FILE, 'r') as f:
                pending_images = json.load(f)
        if os.path.exists(USER_FURSONAS_FILE):
            with open(USER_FURSONAS_FILE, 'r') as f:
                user_fursonas = json.load(f)
    except Exception as e:
        print(f"Error loading saved data: {e}")

# Initialize with empty dictionaries
pending_fursonas = {}
pending_images = {}
user_fursonas = {}

# Load saved data at startup
load_saved_data()

def save_pending_fursonas():
    try:
        with open(PENDING_FURSONAS_FILE, 'w') as f:
            json.dump(pending_fursonas, f)
    except Exception as e:
        print(f"Error saving pending fursonas: {e}")

def save_pending_images():
    try:
        with open(PENDING_IMAGES_FILE, 'w') as f:
            json.dump(pending_images, f)
    except Exception as e:
        print(f"Error saving pending images: {e}")

def save_user_fursonas():
    try:
        with open(USER_FURSONAS_FILE, 'w') as f:
            json.dump(user_fursonas, f)
    except Exception as e:
        print(f"Error saving user fursonas: {e}")

class FursonaSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def ask_fursona_questions(self, member: discord.Member) -> dict:
        """Ask fursona questions via DM"""
        questions = [
            "What's your fursona's name?",
            "What's your fursona's species?",
            "What's your fursona's age?",
            "Please write a brief bio for your fursona:"
        ]

        answers = {}
        try:
            # Initial message
            await member.send("Let's create your fursona! Please answer the following questions:")
            await asyncio.sleep(1)  # Small delay before starting questions

            def check(m):
                return m.author == member and isinstance(m.channel, discord.DMChannel)

            # Process questions one by one
            for question in questions:
                await member.send(question)
                try:
                    response = await self.bot.wait_for('message', timeout=300.0, check=check)
                    answers[question] = response.content
                    await asyncio.sleep(1)  # Small delay between questions
                except asyncio.TimeoutError:
                    await member.send("You took too long to respond. Please try again using !fursona create")
                    return None

            return answers

        except discord.Forbidden:
            print(f"Could not DM user {member.name}")
            return None

    @commands.group(invoke_without_command=True)
    async def fursona(self, ctx):
        """Base fursona command"""
        if ctx.invoked_subcommand is None:
            await ctx.send("Available commands:\n"
                          "!fursona create - Create a new fursona\n"
                          "!fursona delete - Delete your fursona\n"
                          "!fursona image add - Add an image to your fursona\n"
                          "!fursona view - View your fursona\n"
                          "!fursona view @user - View someone else's fursona")

    @fursona.command(name='view')
    async def fursona_view(self, ctx, member: discord.Member = None):
        """View a fursona"""
        # If no member specified, show own fursona
        target_member = member or ctx.author

        if str(target_member.id) not in user_fursonas:
            if member:
                await ctx.send(f"{target_member.name} doesn't have a fursona!")
            else:
                await ctx.send("You don't have a fursona! Use !fursona create to make one.")
            return

        # Create embed
        embed = discord.Embed(
            title=f"{target_member.name}'s Fursona",
            color=discord.Color.blue()
        )

        fursona_data = user_fursonas[str(target_member.id)]

        # Add basic information
        if "What's your fursona's name?" in fursona_data:
            embed.add_field(name="Name", value=fursona_data["What's your fursona's name?"], inline=True)
        if "What's your fursona's species?" in fursona_data:
            embed.add_field(name="Species", value=fursona_data["What's your fursona's species?"], inline=True)
        if "What's your fursona's age?" in fursona_data:
            embed.add_field(name="Age", value=fursona_data["What's your fursona's age?"], inline=True)
        if "Please write a brief bio for your fursona:" in fursona_data:
            embed.add_field(name="Bio", value=fursona_data["Please write a brief bio for your fursona:"], inline=False)

        # Add image if exists
        if 'image_url' in fursona_data:
            embed.set_image(url=fursona_data['image_url'])

        await ctx.send(embed=embed)

    @fursona.command(name='create')
    async def fursona_create(self, ctx):
        """Create a new fursona"""
        if str(ctx.author.id) in user_fursonas:
            await ctx.send("You already have a fursona! Use !fursona delete to remove it first.")
            return

        if str(ctx.author.id) in pending_fursonas:
            await ctx.send("You already have a pending fursona application!")
            return

        answers = await self.ask_fursona_questions(ctx.author)
        if not answers:
            return

        embed = discord.Embed(
            title="New Fursona Application",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="User Information",
            value=f"Name: {ctx.author.name}#{ctx.author.discriminator}\n"
                  f"ID: {ctx.author.id}",
            inline=False
        )

        for question, answer in answers.items():
            embed.add_field(
                name=question,
                value=answer,
                inline=False
            )

        mod_channel = self.bot.get_channel(config.FURSONA_APPROVAL_CHANNEL_ID)
        if not mod_channel:
            await ctx.author.send("There was an error submitting your fursona. Please try again later.")
            return

        verify_message = await mod_channel.send(embed=embed)
        await verify_message.add_reaction(config.APPROVE_EMOJI)
        await verify_message.add_reaction(config.DENY_EMOJI)

        # Store as strings to ensure JSON serialization
        pending_fursonas[str(ctx.author.id)] = {
            'answers': answers,
            'message_id': str(verify_message.id)
        }
        save_pending_fursonas()

        await ctx.author.send("Your fursona application has been submitted for review!")

    @fursona.command(name='delete')
    async def fursona_delete(self, ctx):
        """Delete your fursona"""
        if str(ctx.author.id) not in user_fursonas:
            await ctx.send("You don't have a fursona to delete!")
            return

        del user_fursonas[str(ctx.author.id)]
        save_user_fursonas()
        await ctx.send("Your fursona has been deleted.")

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload):
        """Handle moderator approval/denial of fursonas and images"""
        if payload.user_id == self.bot.user.id:
            return

        if payload.channel_id != config.FURSONA_APPROVAL_CHANNEL_ID:
            return

        message = await self.bot.get_channel(payload.channel_id).fetch_message(payload.message_id)
        if not message or not message.embeds:
            return

        guild = self.bot.get_guild(payload.guild_id)
        mod = guild.get_member(payload.user_id)
        if not mod or not any(role.id == config.MOD_ROLE_ID for role in mod.roles):
            return

        embed = message.embeds[0]

        if embed.title == "New Fursona Application":
            # Extract user ID from embed
            user_id = str(int(embed.fields[0].value.split('ID: ')[1].split('\n')[0]))
            user = guild.get_member(int(user_id))

            # Handle approval
            if str(payload.emoji) == config.APPROVE_EMOJI:
                # Get answers either from pending_fursonas or extract from embed
                if user_id in pending_fursonas:
                    answers = pending_fursonas[user_id]['answers']
                else:
                    # Extract answers from embed if not in memory
                    answers = {}
                    for field in embed.fields[1:]:  # Skip user info field
                        answers[field.name] = field.value

                # Store fursona data
                user_fursonas[user_id] = answers
                save_user_fursonas()

                # Clean up pending application
                if user_id in pending_fursonas:
                    del pending_fursonas[user_id]
                    save_pending_fursonas()

                # Update embed and log
                embed.color = discord.Color.green()
                embed.add_field(name="Status", value=f"Approved by {mod.name}#{mod.discriminator}")

                # Log the approval
                log_channel = self.bot.get_channel(config.FURSONA_LOG_CHANNEL_ID)
                if log_channel:
                    await log_channel.send(embed=embed)

                # Delete original message
                await message.delete()

                if user:
                    await user.send("Your fursona has been approved!")

            elif str(payload.emoji) == config.DENY_EMOJI:
                # Clean up pending application
                if user_id in pending_fursonas:
                    del pending_fursonas[user_id]
                    save_pending_fursonas()

                embed.color = discord.Color.red()
                embed.add_field(name="Status", value=f"Denied by {mod.name}#{mod.discriminator}")

                # Log the denial
                log_channel = self.bot.get_channel(config.FURSONA_LOG_CHANNEL_ID)
                if log_channel:
                    await log_channel.send(embed=embed)

                # Delete original message
                await message.delete()

                if user:
                    await user.send("Your fursona application has been denied.")

        elif embed.title == "New Fursona Image Submission":
            # Handle image approval/denial similarly...
            user_id_list = [uid for uid, data in pending_images.items() if str(data['message_id']) == str(message.id)]
            if user_id_list:
                user_id = user_id_list[0]
                if str(payload.emoji) == config.APPROVE_EMOJI:
                    if user_id in user_fursonas:
                        user_fursonas[user_id]['image_url'] = pending_images[user_id]['url']
                        save_user_fursonas()

                    if user_id in pending_images:
                        del pending_images[user_id]
                        save_pending_images()

                    embed.color = discord.Color.green()
                    embed.add_field(name="Status", value=f"Approved by {mod.name}#{mod.discriminator}")

                    # Log the approval
                    log_channel = self.bot.get_channel(config.FURSONA_LOG_CHANNEL_ID)
                    if log_channel:
                        await log_channel.send(embed=embed)

                    # Delete original message
                    await message.delete()

                    user = guild.get_member(int(user_id))
                    if user:
                        await user.send("Your fursona image has been approved!")

                elif str(payload.emoji) == config.DENY_EMOJI:
                    if user_id in pending_images:
                        del pending_images[user_id]
                        save_pending_images()

                    embed.color = discord.Color.red()
                    embed.add_field(name="Status", value=f"Denied by {mod.name}#{mod.discriminator}")

                    # Log the denial
                    log_channel = self.bot.get_channel(config.FURSONA_LOG_CHANNEL_ID)
                    if log_channel:
                        await log_channel.send(embed=embed)

                    # Delete original message
                    await message.delete()

                    user = guild.get_member(int(user_id))
                    if user:
                        await user.send("Your fursona image has been denied.")

    @fursona.group(name='image', invoke_without_command=True)
    async def fursona_image(self, ctx):
        """Base command for fursona image management"""
        if ctx.invoked_subcommand is None:
            await ctx.send("Use !fursona image add to add an image to your fursona")

    @fursona_image.command(name='add')
    async def fursona_image_add(self, ctx):
        """Add an image to your fursona"""
        if str(ctx.author.id) not in user_fursonas:
            await ctx.send("You need to create a fursona first!")
            return

        if str(ctx.author.id) in pending_images:
            await ctx.send("You already have a pending image approval!")
            return

        await ctx.author.send("Please send your fursona image. Only one image will be accepted.")

        def check(m):
            return m.author == ctx.author and isinstance(m.channel, discord.DMChannel) and m.attachments

        try:
            response = await self.bot.wait_for('message', timeout=300.0, check=check)
            image_url = response.attachments[0].url

            embed = discord.Embed(
                title="New Fursona Image Submission",
                color=discord.Color.blue()
            )
            embed.set_author(name=f"{ctx.author.name}#{ctx.author.discriminator}")
            embed.set_image(url=image_url)

            mod_channel = self.bot.get_channel(config.FURSONA_APPROVAL_CHANNEL_ID)
            verify_message = await mod_channel.send(embed=embed)
            await verify_message.add_reaction(config.APPROVE_EMOJI)
            await verify_message.add_reaction(config.DENY_EMOJI)

            # Store as strings to ensure JSON serialization
            pending_images[str(ctx.author.id)] = {
                'url': image_url,
                'message_id': str(verify_message.id)
            }
            save_pending_images()

            await ctx.author.send("Your fursona image has been submitted for review!")

        except asyncio.TimeoutError:
            await ctx.author.send("You took too long to send an image. Please try again.")

async def setup(bot):
    await bot.add_cog(FursonaSystem(bot))