import discord
from discord.ext import commands
import asyncio
import config
import os

# Initialize bot with intents
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.reactions = True
intents.guilds = True  # Add guild intent

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'Bot is ready! Logged in as {bot.user.name}')
    print('------')
    # Check bot permissions
    for guild in bot.guilds:
        print(f"Connected to guild: {guild.name}")
        channel = guild.get_channel(config.VERIFICATION_CHANNEL_ID)
        if channel:
            permissions = channel.permissions_for(guild.me)
            print(f"Bot permissions in verification channel {channel.name}:")
            print(f"Send Messages: {permissions.send_messages}")
            print(f"Read Messages: {permissions.read_messages}")
            print(f"Add Reactions: {permissions.add_reactions}")
            print(f"Manage Messages: {permissions.manage_messages}")
        else:
            print(f"Could not find verification channel {config.VERIFICATION_CHANNEL_ID}")

@bot.event
async def on_disconnect():
    print("Bot disconnected from Discord. Attempting to reconnect...")

@bot.event
async def on_error(event, *args, **kwargs):
    """Log any errors that occur"""
    print(f"Error in {event}: {args} {kwargs}")
    import traceback
    traceback.print_exc()

@bot.command(name='commands')
async def list_commands(ctx):
    """Show all available bot commands"""
    embed = discord.Embed(
        title="Available Commands",
        description="Here are all the commands you can use:",
        color=discord.Color.blue()
    )

    # Check if user is a moderator or admin
    is_mod = any(role.id == config.MOD_ROLE_ID for role in ctx.author.roles)
    is_admin = ctx.author.guild_permissions.administrator

    # Admin Commands
    if is_admin:
        admin_commands = "`!givexp @user amount` - Give XP to a user\n"
        admin_commands += "`!removexp @user amount` - Remove XP from a user\n"
        embed.add_field(name="Admin Commands", value=admin_commands, inline=False)

    # Reaction Roles Commands
    rr_commands = ""
    if is_mod:
        rr_commands += "`!rrsetup` - Set up reaction roles in the current channel\n"
        rr_commands += "`!rrrefresh` - Refresh all reaction role messages\n"
        rr_commands += "`!rrcategory add <name> <emoji>` - Add a new role category\n"
        rr_commands += "`!rrcategory remove <name>` - Remove a role category\n"
        rr_commands += "`!rrcategory list` - List all role categories\n"
        rr_commands += "`!rradd <category> <@role> <emoji>` - Add a role to a category\n"
        rr_commands += "`!rrremove <category> <emoji>` - Remove a role from a category\n"
        rr_commands += "`!rrlist` - List all reaction roles and categories\n"
        rr_commands += "`!clear [amount]` - Clear messages in the channel (all if no amount specified)\n"
        rr_commands += "`!rulessetup` - Set up the server rules in the current channel\n"
        rr_commands += "`!verificationsetup` - Set up the verification system in the current channel\n"
        embed.add_field(name="Moderation Commands", value=rr_commands, inline=False)

    # Verification System
    verify_desc = "React with ✅ in the verification channel to start the verification process\n"
    embed.add_field(name="Verification", value=verify_desc, inline=False)

    # Fursona Commands
    fursona_commands = "`!fursona create` - Create a new fursona\n"
    fursona_commands += "`!fursona delete` - Delete your fursona\n"
    fursona_commands += "`!fursona image add` - Add an image to your fursona\n"
    fursona_commands += "`!fursona view` - View your fursona\n"
    fursona_commands += "`!fursona view @user` - View someone else's fursona\n"
    embed.add_field(name="Fursona System", value=fursona_commands, inline=False)

    # General Commands
    general_commands = "`!commands` - Show this help message\n"
    general_commands += "`!rank` - Show your current level and XP\n"
    general_commands += "`!rank @user` - Show another user's level and XP\n"
    general_commands += "`!leaderboard` - Show the server's top 10 members\n"
    embed.add_field(name="General", value=general_commands, inline=False)

    # Add footer with additional info
    embed.set_footer(text="Use ! before each command. For more details about a command, use !help <command>")

    await ctx.send(embed=embed)

@bot.event
async def on_command(ctx):
    """Log when commands are received"""
    print(f"Command received: {ctx.command.name} from {ctx.author}")

@bot.event
async def on_command_error(ctx, error):
    """Log command errors"""
    print(f"Command error: {str(error)}")
    if isinstance(error, commands.errors.CommandNotFound):
        print(f"Command not found: {ctx.message.content}")
    elif isinstance(error, commands.errors.MissingPermissions):
        print(f"Missing permissions for command: {ctx.command.name}")
    else:
        print(f"Unexpected error: {str(error)}")

async def load_cogs():
    """Load all cogs"""
    for filename in os.listdir('./handlers'):
        if filename.endswith('.py'):
            try:
                await bot.load_extension(f'handlers.{filename[:-3]}')
                print(f'Loaded {filename}')
            except Exception as e:
                print(f'Failed to load {filename}')
                print(f'Error: {str(e)}')

async def main():
    """Main function to start the bot"""
    async with bot:
        await load_cogs()
        await bot.start(config.TOKEN)

# Run the bot with auto-reconnect
if __name__ == "__main__":
    while True:
        try:
            asyncio.run(main())
        except Exception as e:
            print(f"Bot crashed with error: {str(e)}")
            print("Restarting bot in 5 seconds...")
            # Use time.sleep instead of asyncio.sleep since we're in synchronous context
            import time
            time.sleep(5)